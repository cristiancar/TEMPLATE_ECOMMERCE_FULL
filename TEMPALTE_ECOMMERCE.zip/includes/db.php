<?php

$con = mysqli_connect("localhost","root","Imaginaudio2022","ecom_store");

?>
